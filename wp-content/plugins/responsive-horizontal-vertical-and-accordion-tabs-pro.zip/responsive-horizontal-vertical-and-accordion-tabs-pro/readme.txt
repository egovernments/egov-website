=== WP Responsive Tabs horizontal vertical and accordion Tabs Pro ===
Contributors:nik00726
Donate link:http://www.i13websolution.com/donate-wordpress_image_thumbnail.php
Tags:Accordion tabs, Vertical tabs,horizontal tabs,wp tabs,Responsive Tabs, All in one tabs
Requires at least:3.0
Tested up to:5.5
Version:2.14
Stable tag:2.14
License:GPLv2 or later
License URI:http://www.gnu.org/licenses/gpl-2.0.html

== Description ==


Create beautiful responsive tabs with a very easy interface. This plugin is all in one tabs plugin means it supports responsive horizontal, vertical and accordion tabs. no coding knowledge required, Just create tab set and create tabs contents and that's all and you can now use shortcode to print tabs.admin can choose border color, content color, font color, and many other settings. Even admin can preview tab sets before use.



**Live Demo  [Responsive Tabs Plugins](http://blog.i13websolution.com/wordpress-responsive-horizontal-vertical-scrollable-and-accordion-tabs/)**

**Upgrade to Responsive Tabs Plugins ( Support Scrollable Tabs + More) at [WordPress Responsive Tabs Pro](https://www.i13websolution.com/product/best-wordpress-responsive-tabs-plugin/)**

**Responsive Tabs Plugins Video**

[youtube https://www.youtube.com/watch?v=hzZpCH4jGIY ]



**Please rate this plugin if you find it useful**


**=Features=**


1. Add any number of tab sets

2. support horizontal, vertical and accordion tabs

3. set tabs order

4. Preview tabs before use.

6. Use shortcodes.

7. choose color settings as per requirements

8. Responsive support

9. WordPress capebilities feature


**=Pro Version Features=**

1. Support scrollable tabs.

2. Support selected tab through url like ?selected_tab=2.

3. support font awesome icon for tab title

4. Additonal CSS for tab sets.

5. Mass order updates.

6. WordPress capebilities feature.




[Get Support](http://www.i13websolution.com/contacts)


== Installation ==

This plugin is easy to install like other plug-ins of Wordpress as you need to just follow the below mentioned steps:

1. upload responsive-horizontal-vertical-and-accordion-tabs folder to wp-Content/plugins folder.

2. Activate the plugin from Dashboard / Plugins window.

4. Now Plugin is Activated, Go to the Usage section to see how to use Responsive Tabs section.


### Usage ###

1.Use of wordpress responsive tabs is easy after activating plugin go to Responsive Tabs.

2.You can manage tabs by Manage tabs menu.

3.You can add this Responsive Tabs to your wordpress page/post by shortcode



== License ==

This plugin is free for everyone! Since it's released under the GPL, you can use it free of charge on your personal or commercial blog. But you can make some donations if you realy find it useful.


== Screenshots ==

1. Manage Tab sets
2. Manage Tab Contents
3. Add/Edit tabs
4. Pro Version Add/Edit tabs
5. WordPress responsive horizontal tabs
6. Pro Version WordPress responsive scrollable horizontal tabs
7. WordPress responsive vertical tabs
8. WordPress responsive accordion tabs



== Changelog ==

= 2.13 =

* Removed jQuery.noConflict() as it cause direct usage of $


= 2.12 =

* Fixed issue of scrolling tabs for 2020 theme
* Added feature to updates in pro version
* Tested with WordPress 5.4


= 2.11 =

* Improve tabs loading

= 1.1.5 =

* fixed issue of <p> and <br/> tags removed from content
* Added support of extra css for each tabset settings so that user can add own css
* Added feature for use ajax for first time tab content load or not?


= 1.1.4 =

* improve code so that it continue work with even jquery in footer.
* Tested with WordPress 5.2



= 1.1.3 =

* Added WordPress capebilities feature


= 1.1.2 =

* Improve security


= 1.1.1 =

* fixed undefined variable problem

= 1.1 =

* Improve admin UI
* Tested with WordPress 5.0

= 1.0 =

* Stable 1.0 first release


== Upgrade notice ==

= 2.11 =

* Clear WordPress cache as well as browser cache after upgrade.


= 1.1.5 =

* Clear WordPress cache as well as browser cache after upgrade.


= 1.1.4 =

* Clear WordPress cache as well as browser cache after upgrade.

= 1.0 =

* Stable 1.0 first release


== Frequently asked questions ==

1.How to use ?

For More info use readme installation and usage notes.
