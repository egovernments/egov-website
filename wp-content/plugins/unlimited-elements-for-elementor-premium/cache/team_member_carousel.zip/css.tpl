#{{uc_id}} *{
  box-sizing:border-box;
  outline:none;
}
#{{uc_id}}{
  position:relative;
  min-height:1px;
}

#{{uc_id}} .ue-additional-image
{
  {{image_snap_horizontal}}:{{horizontal_offset}}px;
  {{image_snap_vertical}}:{{vertical_offset}}px;
}


#{{uc_id}} .ue-company-logo img
{
  width:100%;
}

#{{uc_id}} .ue-additional-image img
{
  width:100%;
}

#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
   transition:0.3s;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
  transition:0.3s;
}

#{{uc_id}} .owl-dots {
overflow:hidden;
display:{{show_dots}} !important;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {

display:inline-block;
  transition:0.5s;
}

#{{uc_id}} .team_member_carousel_image
{
  position:relative;
  display:flex;
  overflow:hidden;
  
}

#{{uc_id}} .team_member_carousel_image_container
{
  position:relative;
  display:block;
  overflow:hidden;
}

#{{uc_id}} .team_member_carousel_image_overlay
{
  position:absolute;
  top:0px;
  left:0px;
  right:0px;
  bottom:0px;
  transition:0.3s;
  display:flex;
  align-items:center;
  justify-content:center;
}

#{{uc_id}} .team_member_carousel_image img
{
  object-fit:cover;
  display:inline-flex;
  transition:0.3s;
}
#{{uc_id}} .ue_carousel_item
{
  overflow:hidden;
  position:relative;
}
.team_member_carousel_title
{
  font-size:18px;
}

#{{uc_id}} .team_member_carousel_icons a
{
  display:inline-flex;
  text-decoration:none;
  align-items:center;
  justify-content:center;
  line-height:1em;
  transition:0.3s;
}

#{{uc_id}} .team_member_carousel_icons a svg
{
  width:1em;
  height:1em;
}

#{{uc_id}} .uc_more_btn
{
  transition:0.3s;
  text-align:center;
  text-decoration:none;
}


#{{uc_id}} .team_member_carousel_text img
{
  width:auto;
}


{% if image_grow_on_hover == "true" %}

#{{uc_id}} .ue_carousel_item:hover .team_member_carousel_image img
{
  transform:scale(1.1,1.1);
}
{% endif %}