<div class="ue_carousel_item ue-item ue-carousel-item">
  {% if show_text_header == "true" %}
  <div class="ue-text-header">{{item.text_header|raw}}</div>
  {% endif %}
  
  {% if show_image == "true" %}
  <div class="team_member_carousel_image">
    <div class="team_member_carousel_image_container">
       <img src="{{item.image}}" alt="{{item.image_alt}}" {{item.image_attributes|raw}}>
       <div class="team_member_carousel_image_overlay">
         {% if show_icons == "overlay" %}
          <div class="team_member_carousel_icons">
            {% if item.icon_one is empty %}{% else %}<a href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
            {% if item.icon_two is empty %}{% else %}<a href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
            {% if item.icon_three is empty %}{% else %}<a href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
            {% if item.icon_four is empty %}{% else %}<a href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
          </div>
          {% endif %}
       </div>
    </div>
  </div>
  {% endif %}
  
  <div class="team_member_carousel_content">
    {% if show_title == "true" %}<div class="team_member_carousel_title">{{item.title|raw}}</div>{% endif %}	
    {% if show_subtitle == "true" %}<div class="team_member_carousel_subtitle">{{item.subtitle|raw}}</div>{% endif %}	
    
    {% if company_logo == "before" %}<div class="ue-company-logo"><img src="{{item.company_logo}}"></div>{% endif %}	
    
    {% if show_icons == "content" and icons_placement == "before" %}
    
   
    
    <div class="team_member_carousel_icons">
      {% if item.icon_one is empty %}{% else %}<a href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
      {% if item.icon_two is empty %}{% else %}<a href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
      {% if item.icon_three is empty %}{% else %}<a href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
      {% if item.icon_four is empty %}{% else %}<a href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
    </div>
    {% endif %}
    
    {% if show_text == "true" %}<div class="team_member_carousel_text">{{item.text|raw}}</div>{% endif %}	
    
    {% if company_logo == "after" %}<div class="ue-company-logo"><img src="{{item.company_logo}}"></div>{% endif %}	
    {% if item.additional_image == "true" %}<div class="ue-additional-image"><img src="{{item.additional_image_img}}"></div>{% endif %}	
    
    
    {% if show_icons == "content" and icons_placement == "after" %}
    <div class="team_member_carousel_icons">
      {% if item.icon_one is empty %}{% else %}<a href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
      {% if item.icon_two is empty %}{% else %}<a href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
      {% if item.icon_three is empty %}{% else %}<a href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
      {% if item.icon_four is empty %}{% else %}<a href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
    </div>
    {% endif %}
    
    {% if show_button == "true" %}
    <div class="team_member_carousel_button">
      <a href="{{item.button_link}}" class="uc_more_btn" {{item.button_link_html_attributes|raw}}>{{button_text}}</a>
    </div>
    {% endif %}
  </div>
</div>