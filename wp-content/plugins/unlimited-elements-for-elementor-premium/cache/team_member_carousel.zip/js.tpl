jQuery(document).ready(function(){	
function {{uc_id}}_start(){
		
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
			loop: {{loop}},
                center:{{center}},  
                shuffle:{{shuffle}},
                autoplayTimeout: {{autoplay_timeout}},
                autoplayHoverPause: {{autoplay_hover_pause}},
                smartSpeed: {{transition_speed}},
                navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],	
                nav: {{show_arrows}},
                rtl:{{rtl}},
                setActiveClassOnMobile:{{active_on_mobile}},
                changeItemOnClick:{{scroll_on_click}},
                navigation:true,
                autoplay: {{autoplay}},
				margin: {{margin_between_items}},
                responsive : {
					0 : {
						items:{{number_of_items_mobile}},
					},
					768 : {
						items:{{number_of_items_tablet}},
					},
					980 : {
						items:{{number_of_items}},
					}
				}
			});
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}  

}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});