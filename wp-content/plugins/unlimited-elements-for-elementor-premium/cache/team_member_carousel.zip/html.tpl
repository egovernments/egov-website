{% if rtl == "false" %}<div  style="direction:ltr;">{% endif %}	
{% if rtl == "true" %}<div  style="direction:rtl;">{% endif %}	
   <div class="ue_carousel owl-carousel owl-theme {{remote_parent.class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
   		{{put_items()}}
   </div>	
</div>