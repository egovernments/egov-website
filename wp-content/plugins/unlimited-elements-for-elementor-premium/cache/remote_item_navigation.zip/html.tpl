<div id="{{uc_id}}" class="remote_item_navigation" {{remote.attributes|raw}}>
  {{put_items()}}
</div>