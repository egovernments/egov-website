jQuery(document).ready(function () {
 
  var objRemoteApi = new UERemoteWidgets();
	  objRemoteApi.onWidgetInit("{{uc_id}}",function(objWidget){
       
       var objButtons = objWidget.find(".ue-item-button");
       updateActiveMode();
        
       // define function set/remove active mote
        
       function updateActiveMode() {
          
         var currentItem = objRemoteApi.doAction("get_num_current"); 
         currentItem++;
         
          objButtons.each(function(event, button){
          		var objButton = jQuery(button);
            	var buttonNumItem = objButton.data("numitem");
                        
            	if(buttonNumItem == currentItem)
              		objButton.addClass("ue-item-active");
               	else
              		objButton.removeClass("ue-item-active");
          });
         
       }
        
       updateActiveMode();
               
       objRemoteApi.onEvent("change", updateActiveMode);

       objButtons.on('click', function() {    
         	var objButton = jQuery(this);
            var buttonNumItem = objButton.data("numitem");
            var itemToSet = buttonNumItem-1;     
        	objRemoteApi.doAction("change_item", itemToSet); 
       });
        
    });
});