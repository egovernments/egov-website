<div class="ue-item-button {{item.item_repeater_class}} {{hover_effect}}" data-numitem="{{item.num_item}}">
  <div class="ue-item-hero">
    
    {% if show_image == "true" %}
        <img src="{{item.image}}" {{item.image_attributes|raw}}>  
    {% endif %}
    
    
    {% if show_icon_inner == "true" %}
        <div class="ue-item-hero-icon">{{item.icon_html|raw}}</div>
    {% endif %}
    
    {% if show_label == "true" %}
    <div class="ue-item-hero-label">{{item.label|raw}}</div>
    {% endif %}
    
    
  </div>
  
  {% if show_title == "true" %}
      <div class="ue-item-button-spacer"></div>
      <div class="ue-item-button-title">{{item.title|raw}}</div>
  {% endif %}
</div>