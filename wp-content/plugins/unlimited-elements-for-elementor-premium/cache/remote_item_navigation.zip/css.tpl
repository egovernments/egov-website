#{{uc_id}}
{
  display:flex;
  flex-wrap: wrap;
}

#{{uc_id}} .ue-item-button
{
  display:flex;
  cursor:pointer;
  transition:0.3s;
}

#{{uc_id}} .ue-item-hero
{
  display:flex;
  justify-content:center;
  align-items:center;
  position:relative;
  line-height:1em;
  transition:0.3s;
}

#{{uc_id}} .ue-item-hero svg
{
  height:1em;
  width:1em;
  transition:0.3s;
}

#{{uc_id}} .ue-item-hero .ue-item-hero-label
{
  position:absolute;
  {{horizontal_snap}}:{{horizontal_space}};
  {{vertical_snap}}:{{vertical_space}};
  display:flex;
  justify-content:center;
  align-items:center;
  transition:0.3s;
}

#{{uc_id}} .ue-item-hero img
{
  width:100%;
  height:100%;
  top:0px;
  left:0px;
  right:0px;
  bottom:0px;
  position:absolute;
  transition:0.3s;
}


{% if ucfunc("run_code_once", "yourkey") == true %}

.ue-item-hero-label
{
  line-height:1em; 
  font-size:10px;
  transition:0.3s;
}

.ue-item-hero-icon
{
  position:relative;
  transition:0.3s;
}

.ue-item-button-title
{
  transition:0.3s;
}

{% endif %}