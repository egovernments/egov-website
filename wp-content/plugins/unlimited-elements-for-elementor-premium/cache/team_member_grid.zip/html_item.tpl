<div class="ue_grid_item">
  <div class="team_member_grid_header">
  {% if image_placement == "header" %}
  <div class="team_member_grid_image">
     <div class="team_member_grid_image_container">
       <img src="{{item.image}}" alt="{{item.image_alt}}" {{item.image_attributes|raw}}>
       <div class="team_member_grid_image_overlay">
         {% if title_placement == "overlay" %}<div class="team_member_grid_title">{{item.title|raw}}</div>{% endif %}	
         {% if subtitle_placement == "overlay" %}<div class="team_member_grid_subtitle">{{item.subtitle|raw}}</div>{% endif %}	
    
         {% if icons_placement == "overlay" %}
            <div class="team_member_grid_icons">
              {% if item.icon_one is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
              {% if item.icon_two is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
              {% if item.icon_three is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
              {% if item.icon_four is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
            </div>
          {% endif %}
       </div>
     </div>
    </div>
  {% endif %}
  {% if title_placement == "header" %}<div class="team_member_grid_title">{{item.title|raw}}</div>{% endif %}	
  {% if subtitle_placement == "header" %}<div class="team_member_grid_subtitle">{{item.subtitle|raw}}</div>{% endif %}	
  {% if icons_placement == "header" %}
            <div class="team_member_grid_icons">
              {% if item.icon_one is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
              {% if item.icon_two is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
              {% if item.icon_three is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
              {% if item.icon_four is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
            </div>
   {% endif %}  
    
    
  </div>
  
  <div class="team_member_grid_content">
    {% if image_placement == "content" %}
     <div class="team_member_grid_image">
     <div class="team_member_grid_image_container">
       <img src="{{item.image}}" alt="{{item.image_alt}}" {{item.image_attributes|raw}}>
       <div class="team_member_grid_image_overlay">
         {% if title_placement == "overlay" %}<div class="team_member_grid_title">{{item.title|raw}}</div>{% endif %}	
         {% if subtitle_placement == "overlay" %}<div class="team_member_grid_subtitle">{{item.subtitle|raw}}</div>{% endif %}	
         {% if icons_placement == "overlay" %}
            <div class="team_member_grid_icons">
              {% if item.icon_one is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
              {% if item.icon_two is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
              {% if item.icon_three is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
              {% if item.icon_four is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
            </div>
          {% endif %}
       </div>
     </div>
    </div>
    {% endif %}
    
    {% if title_placement == "content" %}<div class="team_member_grid_title">{{item.title|raw}}</div>{% endif %}	
    {% if subtitle_placement == "content" %}<div class="team_member_grid_subtitle">{{item.subtitle|raw}}</div>{% endif %}	
    
    
    {% if show_text == "true" %}<div class="team_member_grid_text">{{item.text|raw}}</div>{% endif %}	
    {% if icons_placement == "content" %}
    <div class="team_member_grid_icons">
      {% if item.icon_one is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_one}}" {{item.link_one_html_attributes|raw}}>{{item.icon_one_html|raw}}</a>{% endif %}	
      {% if item.icon_two is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_two}}" {{item.link_two_html_attributes|raw}}>{{item.icon_two_html|raw}}</a>{% endif %}	
      {% if item.icon_three is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_three}}" {{item.link_three_html_attributes|raw}}>{{item.icon_three_html|raw}}</a>{% endif %}	
      {% if item.icon_four is empty %}{% else %}<a class="{{hover_effect}}" href="{{item.link_four}}" {{item.link_four_html_attributes|raw}}>{{item.icon_four_html|raw}}</a>{% endif %}	
    </div>
    {% endif %}
    
    {% if show_button == "true" %}
    <div class="team_member_grid_button">
      <a href="{{item.button_link}}" class="uc_more_btn" {{item.button_link_html_attributes|raw}}>{{button_text}}</a>
    </div>
    {% endif %}
  </div>
</div>