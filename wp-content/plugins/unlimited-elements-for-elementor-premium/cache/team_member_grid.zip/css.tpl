#{{uc_id}} *{
  box-sizing:border-box;
}
#{{uc_id}}
{
  position:relative;
  display:grid;
}


#{{uc_id}} .team_member_grid_image_container
{
  display:inline-block;
  overflow:hidden;
  position:relative;
  vertical-align:bottom;
}

{% if grow_on_hover == "true" %}
#{{uc_id}} .ue_grid_item:hover .team_member_grid_image img
{
  transform:scale(1.1,1.1);
}
{% endif %}

#{{uc_id}} .team_member_grid_image
{
  vertical-align:bottom;
}

#{{uc_id}} .team_member_grid_image img
{
  object-fit:cover;
  width:100%;
  display:block;
  transition:0.5s;
  vertical-align:bottom;
}
#{{uc_id}} .ue_grid_item
{
  overflow:hidden;
}
.team_member_grid_title
{
  font-size:18px;
}

#{{uc_id}} .team_member_grid_icons a
{
  display:inline-flex;
  text-decoration:none;
  align-items:center;
  justify-content:center;
  line-height:1em;
  transition:0.3s;
}

#{{uc_id}} .team_member_grid_icons a svg
{
  width:1em;
  height:1em;
}

#{{uc_id}} .uc_more_btn
{
  transition:0.3s;
  text-align:center;
  text-decoration:none;
}

#{{uc_id}} .team_member_grid_image_overlay
{
  position:absolute;
  {{overlay_snap}}:0;
  left:0;
  transition:0.3s;
  display:flex;
  flex-direction:column;
  justify-content:center;
  align-items:center;
}