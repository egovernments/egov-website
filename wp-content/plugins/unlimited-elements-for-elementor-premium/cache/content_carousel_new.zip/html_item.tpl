<div class="uc_image_carousel_container_holder">
  {% if show_image == "true" %}
  <div class="uc_image_carousel_placeholder">
    <div style="background-image:url({{item.image}});background-position:center; background-repeat:no-repeat;" class="carousel-image"></div>
  </div>
  {% endif %}

  {% if show_content == "true" %}
  <div class="uc_image_carousel_content content-padding">
    
    {% if item.source == "content" %}
        {% if show_title == "true" %}<div class="ue-title">{{item.title|raw}}</div>{% endif %}
        {% if show_intro == "true" %}<div class="ue-text" >{{item.content|raw}}</div>{% endif %}
        {% if show_button == "true" %}<a class="ue-btn uc_more_btn"  href="{{item.link}}" {{item.link_html_attributes|raw}}>{{item.btn_text|raw}}</a>{% endif %}
    {% endif %}
    
    {% if item.source == "template" %}
        {{putElementorTemplate(item.template_templateid)}}
    {% endif %}
  </div>
  {% endif %}
</div>