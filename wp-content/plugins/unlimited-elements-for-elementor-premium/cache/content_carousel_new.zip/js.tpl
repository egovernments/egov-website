jQuery(document).ready(function(){	
function {{uc_id}}_start(){
		
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
			    items: 1,
                loop: {{loop}},
                rtl: {{rtl}},
                center:{{center}},
                autoplayTimeout : {{slide_duration}},
                autoplayHoverPause:{{autoplayhoverpause}},
                paddingType: '{{offset_type}}',
                
                dots: {{show_dots}},
                navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"],
                nav: {{show_arrows}},
                autoplay: {{autoplay}},
				margin: {{margin_between_items}},
                responsive : {
					0 : {
						items:{{number_of_items_mobile}},
                        	
						{% if offset_type != "none" %}
                        stagePadding: {{offset_number_mobile}},
                        {% endif %}
					},
					768 : {
						items:{{number_of_items_tablet}},
                         
                        {% if offset_type != "none" %}
                        stagePadding: {{offset_number_tablet}},
                        {% endif %}
					},
					980 : {
						items:{{number_of_items}},
                                
                        {% if offset_type != "none" %}
                        stagePadding: {{offset_number}},
                        {% endif %}
					} 
			}
		  });
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}  

}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});