#{{uc_id}}{
  position:relative;
  min-height:1px;
}



#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}


#{{uc_id}} .owl-dots {
overflow:hidden;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
border-radius:50%;
display:inline-block;
}

.uc_post_title{
  font-size:21px;
}




#{{uc_id}} .uc_image_carousel_container_holder{
  overflow:hidden;
}

#{{uc_id}} .uc_more_btn{
  
    display:inline-block;
  text-decoration:none;
  text-align:center;
  transition:0.3s;
}


{% if layout == "overlay" %}
	#{{uc_id}} .uc_image_carousel_content    {
      position:absolute;
      top:0px;
      left:0px;
      bottom:0px;
      right:0px;
      opacity:0;
      transition:1s;
      display:flex;
      align-items:center;
      flex-direction:column;
      justify-content: center;
    }

	#{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
      opacity:1;
    }

{% endif %}

#{{uc_id}} .uc_date{
  color:gray;
  padding-top:10px;
  text-style:italic;
}

{% if layout == "partial_overlay" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     bottom:20px;
     left:20px;
     right:20px;
    }
{% endif %}


{% if layout == "overlay_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     bottom:0px;
     left:0px;
     right:0px;
    }
{% endif %}

{% if layout == "partial_overlay" %}
	#{{uc_id}} .uc_image_carousel_content{
     position:absolute;
     bottom:20px;
     left:20px;
     right:20px;
    }
{% endif %}

{% if layout == "under_overlap" %}
	#{{uc_id}} .uc_image_carousel_content{
     margin-left:20px;
      margin-right:20px;
      margin-top:-30px;
      position:relative;
    }
{% endif %}

{% if layout == "reveal_from_bottom" %}
	#{{uc_id}} .uc_image_carousel_content{
        margin-left:0px;
        margin-right:0px;
        margin-top:0px;
        position:absolute;
      	bottom: -100%;
        left: 0;
        right: 0;
        transition: ease-in-out all 0.25s;
      	-webkit-transition: ease-in-out all 0.25s;
    }
    #{{uc_id}} .uc_image_carousel_container_holder:hover .uc_image_carousel_content{
		bottom: 0;
    }
{% endif %}