<div class="uc_overlay_image_carousel" >
   <div class="uc_carousel owl-carousel owl-theme {{remote_parent.class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
   		{{put_items()}}
   </div>	
</div>


<!-- -->