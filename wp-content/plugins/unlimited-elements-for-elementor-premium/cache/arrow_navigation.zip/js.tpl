jQuery(document).ready(function(){
  
	var objRemoteApi = new UERemoteWidgets();
	objRemoteApi.onWidgetInit("{{uc_id}}",function(objWidget){
      
		{% if show_next == "true" %}
		objRemoteApi.setAction("next", ".ue-carousel-next");
         {% endif %}
		
         {% if show_previous == "true" %}
		  objRemoteApi.setAction("prev", ".ue-carousel-prev");
          {% endif %}		
	});		
	
});