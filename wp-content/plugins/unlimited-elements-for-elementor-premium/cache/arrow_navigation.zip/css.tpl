.ue-remote-carousel-navigation-wrapper
{
  display:flex;
}

.ue-remote-carousel-navigation-wrapper .ue-remote-arrow
{
  border:none;
  border-color:transparent;
}

.ue-remote-carousel-navigation-wrapper .ue-remote-arrow:hover
{
  background-color:transparent;
 
}


#{{uc_id}}
{
  display:inline-flex;
}

#{{uc_id}} .ue-remote-arrow
{
  flex-grow:0;
  flex-shrink:0;
  transition:0.3s;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  line-height:1em;
  cursor:pointer;
}


#{{uc_id}} .ue-remote-arrow .ue-carousel-nav-icon
{
  transition:0.3s;
  line-height:1em;
}

#{{uc_id}} .ue-remote-arrow .ue-carousel-nav-icon svg
{
  transition:0.3s;
  height:1em;
  width:1em;
}


#{{uc_id}} .ue-carousel-nav-label
{
  transition:0.3s;
}