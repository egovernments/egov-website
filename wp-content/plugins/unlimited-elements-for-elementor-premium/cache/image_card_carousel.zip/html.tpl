<div class="uc_dark_carousel" style="direction:ltr;" >
   <div class="uc_dark_carousel_box owl-carousel {{remote_parent.class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}}>
      {{put_items()}}
   </div>
</div>