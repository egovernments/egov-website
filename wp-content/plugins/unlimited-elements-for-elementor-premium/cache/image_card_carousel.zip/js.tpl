jQuery(document).ready(function(){	
function {{uc_id}}_start(){
		
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
            loop: {{loop}},
			margin: {{margin}},
			nav: {{show_arrows}},
            navText : ["",""],                                             
            dotsEach:{{dotseach}},
			{% if make_3d == "true" %}center: true,{% endif %}
            autoplay:{{autoplay}},
			navigation:false,
            autoplayTimeout:{{autoplay_interval}},
            smartSpeed: {{transition_speed}},  
			responsiveClass: true,
			responsive: {
			       0 : {
						items:{{number_of_items_mobile}}
					},
					768 : {
						items:{{number_of_items_tablet}}
					},
					980 : {
						items:{{number_of_items}}
					}
			}
		  });
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}
          
        {% if change_item_on_click == "true" %}
        var itemsNumber = objCarousel.find(".owl-item:not(cloned)").length;       
  		var clonedItemsNumber = objCarousel.find(".owl-item.cloned").length / 2; // amount of cloned items on one side
  		var minDeviation = -clonedItemsNumber;
  		var maxDeviation = itemsNumber + (clonedItemsNumber * 2);
  		             
        objCarousel.on("click", ".owl-item", function(){
            for(let i = minDeviation; i <= maxDeviation; i++){
              if(jQuery(this).index() - clonedItemsNumber  == i){
                objCarousel.trigger('to.owl.carousel', [i, 300, true]);
              }
            }
        });
        {% endif %}
        
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});