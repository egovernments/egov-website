<div class="ue-item-holder">
<div class="uc_dark_carousel_container_holder ue-item" >
  
  <div class="uc_dark_carousel_placeholder">
    <a href="{{item.link}}" {{item.link_html_attributes|raw}}><img src="{{item.image}}" alt="{{item.image_alt}}"></a>
    {% if item.badge is empty %}  
    {% else %} 
        <div class="ue-item-badge">{{item.badge|raw}}</div>  
    {% endif %}	
    
  </div>
  
  {% if show_content == "true" %}
  <div class="uc_dark_carousel_content" style="">
    
    {% if show_title == "true" %}
    {% if title_linkable == "true" %}<a href="{{item.link}}" {{item.link_html_attributes|raw}}>{% endif %}
    <h2>{{item.title|raw}}</h2>
    {% if title_linkable == "true" %}</a>{% endif %}
    {% endif %}
    
    {% if show_text == "true" %}<p>{{item.content|raw}}</p>{% endif %}
    
    {% if show_button == "true" %}
    <div class="ue-content-bottom"><a class="uc_more_btn {{button_hover}}" href="{{item.link}}" {{item.link_html_attributes|raw}}>{{item.btn_text|raw}}</a></div>
    {% endif %}
  </div>
    {% endif %}
</div>
</div>