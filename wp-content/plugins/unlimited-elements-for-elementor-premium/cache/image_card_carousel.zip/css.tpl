#{{uc_id}}{
  min-height:1px;
}

#{{uc_id}} .owl-dots {
overflow:hidden;
display:{{show_bullets}} !important;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
border-radius:50%;
display:inline-block;
}

#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    display:inline-block;
    text-align:center;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
  display:inline-block;
  text-align:center;
}

#{{uc_id}} .owl-nav .owl-prev:after{
    content: "←";
}
#{{uc_id}} .owl-nav .owl-next:after{
    content: "→";
}


.uc_dark_carousel *{
	margin:0;
	padding:0;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}

.uc_dark_carousel .uc_dark_carousel_box
{
	margin:0 auto;
}

#{{uc_id}} .uc_dark_carousel_container_holder
{
	font-size:14px;
	overflow:hidden;
	position:relative;
	width:100%;
}

.uc_dark_carousel .uc_dark_carousel_content h2
{
	font-size:21px;
}

#{{uc_id}} .uc_dark_carousel_content
{
  display:flex;
  flex-direction:column;
}

#{{uc_id}} .ue-content-bottom
{
  margin-top:auto;
}

#{{uc_id}}  .uc_dark_carousel_placeholder
{
  position:relative;
}


#{{uc_id}}  .uc_dark_carousel_placeholder img
{
	width:100%;
}

#{{uc_id}} .uc_dark_carousel_content .uc_more_btn {
	display:inline-block;
}

#{{uc_id}} .centered .ue-item{
	border: 3px solid yellow;
}

{% if make_3d == "true" %} 
#{{uc_id}} .ue-item {
	opacity: 0.3;
	transform: scale3d(0.8, 0.8, 1);
	transition: all 0.3s ease-in-out;
}

#{{uc_id}} .active.center .ue-item {
	opacity: 1;
	transform: scale3d(1, 1, 1);
	transition: all 0.3s ease-in-out;
}
{% endif %}

.ue-item-badge
{
  font-size:11px;
}

#{{uc_id}} .ue-item-badge
{
  position:absolute;
  {{badge_horizontal_snap}}:{{badge_horizontal_offset}}px;
  {{badge_vertical_snap}}:{{badge_vertical_offset}}px;
}