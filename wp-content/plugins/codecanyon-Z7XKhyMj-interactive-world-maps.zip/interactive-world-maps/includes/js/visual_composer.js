jQuery(document).ready(function ($) {
	$("#vc-inline-frame").contents().find('head').append('<style type="text/css">.iwm_map_canvas .iwm_placeholder { opacity: 1; }</style>');
});


